import queue
import random
import time
from collections import deque
from enum import Enum, auto

class RequestType(Enum):
    LANDING = auto()
    TAKEOFF = auto()
    EMERGENCY_LANDING = auto()

class FlightRequest:
    def __init__(self, flight_number, request_type):
        self.flight_number = flight_number
        self.request_type = request_type
        self.timestamp = time.time()
    
    def __lt__(self, other):
        # Emergency landings have highest priority
        if self.request_type == RequestType.EMERGENCY_LANDING and other.request_type != RequestType.EMERGENCY_LANDING:
            return True
        if self.request_type != RequestType.EMERGENCY_LANDING and other.request_type == RequestType.EMERGENCY_LANDING:
            return False
        # For same type, earlier requests have priority
        return self.timestamp < other.timestamp

class AirportTrafficControl:
    def __init__(self):
        self.landing_queue = queue.PriorityQueue()
        self.takeoff_queue = deque()
        self.flight_numbers = set()
    
    def generate_flight_number(self):
        while True:
            number = random.randint(100, 999)
            if number not in self.flight_numbers:
                self.flight_numbers.add(number)
                return number
    
    def add_request(self, request_type):
        flight_number = self.generate_flight_number()
        request = FlightRequest(flight_number, request_type)
        
        if request_type == RequestType.TAKEOFF:
            self.takeoff_queue.append(request)
            print(f"Flight {flight_number} requests takeoff")
        else:
            self.landing_queue.put(request)
            if request_type == RequestType.EMERGENCY_LANDING:
                print(f"Flight {flight_number} requests emergency landing")
            else:
                print(f"Flight {flight_number} requests landing")
        
        self.process_requests()
    
    def process_requests(self):
        while not self.landing_queue.empty():
            request = self.landing_queue.get()
            print(f"CONTROL: {request.flight_number} land")
            self.flight_numbers.remove(request.flight_number)
            # Re-check queue in case new emergency landed while processing
            self.process_requests()
            return
        
        while self.takeoff_queue:
            request = self.takeoff_queue.popleft()
            print(f"CONTROL: {request.flight_number} takeoff")
            self.flight_numbers.remove(request.flight_number)
            return
    
    def simulate(self, num_requests=10):
        request_types = [
            RequestType.LANDING,
            RequestType.TAKEOFF,
            RequestType.EMERGENCY_LANDING
        ]
        # Make normal landings and takeoffs more common
        weights = [45, 45, 10]
        
        for _ in range(num_requests):
            # Randomly select a request type
            request_type = random.choices(request_types, weights=weights, k=1)[0]
            self.add_request(request_type)
            # Random delay between requests
            time.sleep(random.uniform(0.5, 2))

if __name__ == "__main__":
    print("Airport Traffic Control Simulation")
    print("---------------------------------")
    airport = AirportTrafficControl()
    airport.simulate(num_requests=15)